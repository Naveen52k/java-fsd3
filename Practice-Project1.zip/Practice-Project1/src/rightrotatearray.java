
public class rightrotatearray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int stepsToRotate = 5;

        System.out.println("Original Array:");
        displayArray(array);

        rightRotateArray(array, stepsToRotate);

        System.out.println("\nArray after right rotation:");
        displayArray(array);
    }

    public static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;
        int[] temp = new int[steps];

        for (int i = 0; i < steps; i++) {
            temp[i] = arr[length - steps + i];
        }

        for (int i = length - 1; i >= steps; i--) {
            arr[i] = arr[i - steps];
        }

        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }

    public static void displayArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

