

class node {
    int data;
    node next;

    node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    node head;

    CircularLinkedList() {
        head = null;
    }

    void insertSorted(int data) {
        node newNode = new node(data);

        if (head == null) {
            head = newNode;
            head.next = head;
            return;
        }

        node current = head;

        if (current.data >= data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        node current = head;

        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);

        System.out.println(head.data);
    }

	public void insertSorted(node temp) {
		// TODO Auto-generated method stub
		
	}

	public void circularlist(node temp) {
		// TODO Auto-generated method stub
		
	}

	public void printList() {
		// TODO Auto-generated method stub
		
	}
}

public class circularlinkedlist {
	public static void main(String[] args) 
    { 
        CircularLinkedList list = new CircularLinkedList(); 
  
        int arr[] = new int[] {12, 56, 2, 11, 1, 90}; 

        node temp = null; 
  
        for (int i = 0; i < 6; i++) 
        { 
            temp = new node(arr[i]); 
            list.circularlist(temp); 
        } 
        
        list.printList(); 
    }
}


