
public class deletelinkedlist {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);

        System.out.println("Original Linked List:");
        linkedList.display();

        int keyToDelete = 20;
        linkedList.deleteKey(keyToDelete);

        System.out.println("Linked List after deleting " + keyToDelete + ":");
        linkedList.display();
    }
}
