
public class FourthsmallestelementFinder {
	private int[] unsortedList;

    public FourthsmallestelementFinder(int[] unsortedList) {
        this.unsortedList = unsortedList;
    }

    public int findFourthSmallest() {
        if (unsortedList.length < 4) {
            System.out.println("There are less than 4 elements in the list.");
            return -1;
        }

        int smallest = Integer.MAX_VALUE;
        int secondSmallest = Integer.MAX_VALUE;
        int thirdSmallest = Integer.MAX_VALUE;
        int fourthSmallest = Integer.MAX_VALUE;

        for (int num : unsortedList) {
            if (num < smallest) {
                fourthSmallest = thirdSmallest;
                thirdSmallest = secondSmallest;
                secondSmallest = smallest;
                smallest = num;
            } else if (num < secondSmallest && num != smallest) {
                fourthSmallest = thirdSmallest;
                thirdSmallest = secondSmallest;
                secondSmallest = num;
            } else if (num < thirdSmallest && num != smallest && num != secondSmallest) {
                fourthSmallest = thirdSmallest;
                thirdSmallest = num;
            } else if (num < fourthSmallest && num != smallest && num != secondSmallest && num != thirdSmallest) {
                fourthSmallest = num;
            }
        }

        return fourthSmallest;
    }
}


