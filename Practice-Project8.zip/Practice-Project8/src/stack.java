
import java.util.Stack;

public class stack {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        stack.push(10);
        stack.push(20);
        stack.push(80);
        stack.push(40);
        stack.push(50);

        System.out.println("Stack after push operations: " + stack);

        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("Stack after pop operation: " + stack);

        // Peek at the top element without removing it
        int topElement = stack.push(null);
        System.out.println("Top element (peek): " + topElement);
        System.out.println("Stack after peek operation: " + stack);
    }
}

