
public class Main {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        doublyList.insert(10);
        doublyList.insert(20);
        doublyList.insert(30);
        doublyList.insert(40);

        System.out.println("Doubly Linked List (Forward):");
        doublyList.displayForward();

        System.out.println("Doubly Linked List (Backward):");
        doublyList.displayBackward();
    }
    
}
