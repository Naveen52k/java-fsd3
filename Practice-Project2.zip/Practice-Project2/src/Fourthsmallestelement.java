
// FourthSmallestElementFinder.java
public class Fourthsmallestelement {
    public static void main(String[] args) {
        int[] unsortedList = {0, -5, 8, 7, -1, -2, 1, 6, 9};
        FourthsmallestelementFinder Finder = new FourthsmallestelementFinder(unsortedList);

        int fourthSmallest = Finder.findFourthSmallest();
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}



